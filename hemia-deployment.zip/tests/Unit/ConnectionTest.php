<?php

class ConnectionTest extends \PHPUnit\Framework\TestCase
{



   /** @test */
   public function connAdd()
   {

      $DATABASE_HOST = "mysql-app";
      $DATABASE_USER = "adminroot";
      $DATABASE_PASS = "welcome123";
      $DATABASE_NAME = "docRegform2";

      // $users = User::all();
      // // $count = $users->count();
      $conn = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
      $result = $conn;

      $this->assertEquals($conn, $result);
   }
}
